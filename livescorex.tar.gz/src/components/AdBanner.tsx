interface AdBannerProps {
  size?: "sm" | "lg";
}

export function AdBanner({ size = "sm" }: AdBannerProps) {
  return (
    <div className="w-full flex flex-col items-center gap-1" data-testid="ad-banner">
      <span className="text-[9px] font-semibold text-muted-foreground/50 uppercase tracking-[0.15em]">Advertisement</span>
      <div className={`w-full max-w-[320px] ${size === "lg" ? "h-[90px]" : "h-[60px]"} bg-gradient-to-r from-card via-muted/30 to-card border border-border/30 rounded-lg flex items-center justify-center overflow-hidden relative`}>
        <div className="absolute inset-0 bg-[repeating-linear-gradient(45deg,transparent,transparent_10px,rgba(255,255,255,.01)_10px,rgba(255,255,255,.01)_20px)]" />
        <div className="flex items-center gap-2 text-muted-foreground/20">
          <div className="w-6 h-6 rounded border border-muted-foreground/10" />
          <div className="flex flex-col gap-1">
            <div className="w-20 h-1.5 bg-muted-foreground/10 rounded-full" />
            <div className="w-14 h-1.5 bg-muted-foreground/10 rounded-full" />
          </div>
        </div>
      </div>
    </div>
  );
}
