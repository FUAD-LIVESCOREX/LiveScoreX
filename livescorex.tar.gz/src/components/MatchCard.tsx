import { Match } from "@/data/mockData";

interface MatchCardProps {
  match: Match;
  featured?: boolean;
}

const teamColors: Record<string, string> = {
  RMA: "bg-yellow-500", BAR: "bg-red-500", MCI: "bg-sky-400", ARS: "bg-red-600",
  LIV: "bg-red-700", CHE: "bg-blue-600", BAY: "bg-red-800", PSG: "bg-blue-800",
  JUV: "bg-zinc-800", INT: "bg-indigo-700", IND: "bg-blue-700", AUS: "bg-yellow-600",
  ENG: "bg-sky-600", SA: "bg-green-700", PAK: "bg-green-800", NZ: "bg-black",
  WI: "bg-amber-700", SL: "bg-blue-500", ATM: "bg-red-700", ATH: "bg-red-600",
};

function TeamBadge({ code, size = "sm" }: { code: string; size?: "sm" | "md" | "lg" }) {
  const color = teamColors[code] ?? "bg-primary/40";
  const sizes = { sm: "w-8 h-8 text-[10px]", md: "w-11 h-11 text-xs", lg: "w-16 h-16 text-sm" };
  return (
    <div className={`${sizes[size]} ${color} rounded-full flex items-center justify-center text-white font-black shrink-0`}>
      {code.slice(0, 3)}
    </div>
  );
}

function StatusBadge({ match }: { match: Match }) {
  if (match.status === "LIVE") {
    return (
      <div className="flex items-center gap-1.5 text-live font-bold text-xs rounded-full px-2 py-0.5 bg-live/10">
        <span className="w-1.5 h-1.5 rounded-full bg-live animate-pulse" />
        {match.time ?? "LIVE"}
      </div>
    );
  }
  if (match.status === "HT") {
    return <span className="text-xs font-bold text-amber-400 bg-amber-400/10 px-2 py-0.5 rounded-full">HT</span>;
  }
  if (match.status === "FT") {
    return <span className="text-xs font-bold text-muted-foreground bg-muted px-2 py-0.5 rounded-full">FT</span>;
  }
  return <span className="text-xs font-semibold text-muted-foreground">{match.time}</span>;
}

export function MatchCard({ match, featured }: MatchCardProps) {
  const isLive = match.status === "LIVE";
  const isUpcoming = match.status === "Upcoming";

  if (featured) {
    return (
      <div className="relative overflow-hidden rounded-2xl border border-border cursor-pointer group" data-testid={`match-card-${match.id}`}>
        <div className="absolute inset-0 bg-gradient-to-br from-primary/20 via-card to-card" />
        <div className="absolute top-0 right-0 w-48 h-48 bg-primary/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/3 pointer-events-none" />
        <div className="relative z-10 p-5 flex flex-col gap-4">
          <div className="flex justify-between items-center">
            <span className="text-[10px] font-bold uppercase tracking-widest text-primary bg-primary/10 px-2 py-0.5 rounded-full">{match.competition}</span>
            <StatusBadge match={match} />
          </div>
          <div className="flex justify-between items-center gap-4">
            <div className="flex flex-col items-center gap-2 flex-1">
              <TeamBadge code={match.team1Code} size="lg" />
              <span className="font-bold text-sm text-center leading-tight">{match.team1}</span>
            </div>
            <div className="flex flex-col items-center gap-1 shrink-0">
              {isUpcoming ? (
                <span className="text-lg font-bold text-muted-foreground">vs</span>
              ) : (
                <div className="text-4xl font-black tabular-nums tracking-tighter">
                  {match.score1} <span className="text-muted-foreground/40">-</span> {match.score2}
                </div>
              )}
            </div>
            <div className="flex flex-col items-center gap-2 flex-1">
              <TeamBadge code={match.team2Code} size="lg" />
              <span className="font-bold text-sm text-center leading-tight">{match.team2}</span>
            </div>
          </div>
          {match.scorers && match.scorers.length > 0 && (
            <div className="text-xs text-muted-foreground border-t border-border/50 pt-3 leading-relaxed">
              {match.scorers.join(" • ")}
            </div>
          )}
          {match.details && match.sport === "Cricket" && (
            <div className="text-xs font-semibold text-amber-400 border-t border-border/50 pt-3">{match.details}</div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="bg-card border border-card-border rounded-xl overflow-hidden hover:border-primary/40 transition-all duration-200 cursor-pointer group" data-testid={`match-card-${match.id}`}>
      <div className="px-4 py-2.5 bg-muted/20 border-b border-card-border flex justify-between items-center">
        <span className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">{match.competition}</span>
        <StatusBadge match={match} />
      </div>

      <div className="p-4 flex flex-col gap-3">
        {match.sport === "Cricket" ? (
          <>
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-3">
                <TeamBadge code={match.team1Code} />
                <span className="font-semibold text-sm">{match.team1}</span>
              </div>
              <span className={`font-bold tabular-nums ${isLive ? "text-foreground text-base" : "text-muted-foreground"}`}>
                {match.score1 ?? (isUpcoming ? "" : "-")}
              </span>
            </div>
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-3">
                <TeamBadge code={match.team2Code} />
                <span className="font-semibold text-sm">{match.team2}</span>
              </div>
              <span className={`font-bold tabular-nums ${isLive ? "text-muted-foreground text-sm" : "text-muted-foreground"}`}>
                {match.score2 ? `${match.score2}` : (isUpcoming ? "" : "-")}
              </span>
            </div>
            {match.batting && isLive && (
              <div className="pt-1 border-t border-border/40 text-xs text-muted-foreground font-medium">{match.batting}</div>
            )}
            {isLive && match.crr && match.rrr && (
              <div className="flex gap-3 text-xs font-semibold">
                <span className="text-muted-foreground">CRR <span className="text-foreground">{match.crr}</span></span>
                <span className="text-muted-foreground">RRR <span className="text-amber-400">{match.rrr}</span></span>
              </div>
            )}
            {match.details && (
              <div className={`text-xs font-semibold ${isLive ? "text-amber-400" : "text-muted-foreground"}`}>{match.details}</div>
            )}
          </>
        ) : (
          <>
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-3">
                <TeamBadge code={match.team1Code} />
                <span className="font-semibold text-sm">{match.team1}</span>
              </div>
              <span className={`font-bold text-lg tabular-nums ${isLive || match.status === "HT" ? "text-foreground" : "text-muted-foreground"}`}>
                {match.score1 ?? (isUpcoming ? "" : "-")}
              </span>
            </div>
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-3">
                <TeamBadge code={match.team2Code} />
                <span className="font-semibold text-sm">{match.team2}</span>
              </div>
              <span className={`font-bold text-lg tabular-nums ${isLive || match.status === "HT" ? "text-foreground" : "text-muted-foreground"}`}>
                {match.score2 ?? (isUpcoming ? "" : "-")}
              </span>
            </div>
            {match.scorers && match.scorers.length > 0 && (
              <div className="pt-1 border-t border-border/40 text-xs text-muted-foreground leading-relaxed">
                {match.scorers.join(" • ")}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
