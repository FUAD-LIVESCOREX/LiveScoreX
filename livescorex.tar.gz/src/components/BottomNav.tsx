import { Link, useLocation } from "wouter";
import { Home, Activity, Newspaper } from "lucide-react";

const FootballIcon = ({ className }: { className?: string }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" className={className}>
    {/* Ball outline */}
    <circle cx="12" cy="12" r="10" />
    {/* Central pentagon */}
    <polygon points="12,8.5 15.3,10.9 14.1,14.8 9.9,14.8 8.7,10.9" />
    {/* Lines from pentagon vertices to ball edge */}
    <line x1="12"   y1="8.5"  x2="12"   y2="2"    />
    <line x1="15.3" y1="10.9" x2="21.5" y2="8.9"  />
    <line x1="14.1" y1="14.8" x2="17.9" y2="20.1" />
    <line x1="9.9"  y1="14.8" x2="6.1"  y2="20.1" />
    <line x1="8.7"  y1="10.9" x2="2.5"  y2="8.9"  />
  </svg>
);

const CricketIcon = ({ className }: { className?: string }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" className={className}>
    {/* Bat handle */}
    <line x1="3" y1="4" x2="9.5" y2="10.5" strokeWidth="2" />
    {/* Bat blade */}
    <path d="M9.5 10.5 Q14 8 15.5 12.5 Q16.5 16 13 19 Q9 21.5 6.5 18.5 Z" />
    {/* 3 stumps */}
    <line x1="17" y1="22" x2="17" y2="13" />
    <line x1="19.5" y1="22" x2="19.5" y2="13" />
    <line x1="22" y1="22" x2="22" y2="13" />
    {/* Bails on top of stumps */}
    <line x1="16.5" y1="13" x2="19"   y2="12.3" />
    <line x1="19"   y1="12.3" x2="22.5" y2="13" />
  </svg>
);

const navItems = [
  { path: "/",         label: "Home",     Icon: Home },
  { path: "/football", label: "Football",  Icon: FootballIcon },
  { path: "/cricket",  label: "Cricket",   Icon: CricketIcon },
  { path: "/live",     label: "Live",      Icon: Activity, live: true },
  { path: "/news",     label: "News",      Icon: Newspaper },
];

export function BottomNav() {
  const [location] = useLocation();

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 md:hidden bg-card/95 backdrop-blur-xl border-t border-border safe-area-pb">
      <div className="flex justify-around items-center h-16 px-2">
        {navItems.map(({ path, label, Icon, live }) => {
          const isActive = path === "/" ? location === "/" : location.startsWith(path);
          return (
            <Link
              key={path}
              href={path}
              className="flex-1 flex flex-col items-center justify-center gap-1 py-1 relative"
              data-testid={`nav-${label.toLowerCase()}`}
            >
              {isActive && (
                <div className="absolute top-0 left-1/2 -translate-x-1/2 w-8 h-0.5 bg-primary rounded-full" />
              )}
              <div className="relative">
                <Icon className={`w-5 h-5 transition-colors ${isActive ? "text-primary" : "text-muted-foreground"}`} />
                {live && (
                  <span className="absolute -top-0.5 -right-0.5 w-1.5 h-1.5 rounded-full bg-live animate-pulse" />
                )}
              </div>
              <span className={`text-[10px] font-semibold transition-colors leading-none ${isActive ? "text-primary" : "text-muted-foreground"}`}>
                {label}
              </span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
