import { Search, Bell } from "lucide-react";
import { Link } from "wouter";

export function Header() {
  return (
    <header className="sticky top-0 z-50 bg-background/80 backdrop-blur-xl border-b border-border">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 md:px-8 h-14 flex items-center justify-between gap-4">
        <Link href="/" className="flex items-center gap-2.5 shrink-0" data-testid="header-logo">
          <div className="w-7 h-7 rounded-lg bg-primary flex items-center justify-center">
            <span className="text-white font-black text-base italic leading-none">X</span>
          </div>
          <span className="text-lg font-black tracking-tight">
            LiveScore<span className="text-primary italic">X</span>
          </span>
        </Link>

        <div className="hidden md:flex items-center gap-1 text-sm font-semibold">
          <Link href="/" className="px-3 py-1.5 rounded-lg hover:bg-accent text-muted-foreground hover:text-foreground transition-colors">Home</Link>
          <Link href="/football" className="px-3 py-1.5 rounded-lg hover:bg-accent text-muted-foreground hover:text-foreground transition-colors">Football</Link>
          <Link href="/cricket" className="px-3 py-1.5 rounded-lg hover:bg-accent text-muted-foreground hover:text-foreground transition-colors">Cricket</Link>
          <Link href="/live" className="px-3 py-1.5 rounded-lg hover:bg-accent text-muted-foreground hover:text-foreground transition-colors flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-live animate-pulse" />
            Live
          </Link>
          <Link href="/news" className="px-3 py-1.5 rounded-lg hover:bg-accent text-muted-foreground hover:text-foreground transition-colors">News</Link>
        </div>

        <div className="flex items-center gap-1">
          <button className="relative p-2 rounded-full hover:bg-accent transition-colors" data-testid="header-notifications">
            <Bell className="w-4.5 h-4.5 text-muted-foreground" />
            <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-live border-2 border-background" />
          </button>
          <button className="p-2 rounded-full hover:bg-accent transition-colors" data-testid="header-search">
            <Search className="w-4.5 h-4.5 text-muted-foreground" />
          </button>
        </div>
      </div>
    </header>
  );
}
