export type Sport = "Football" | "Cricket";
export type MatchStatus = "LIVE" | "FT" | "HT" | "Upcoming";

export interface Match {
  id: string;
  sport: Sport;
  competition: string;
  team1: string;
  team1Code: string;
  team2: string;
  team2Code: string;
  score1?: string;
  score2?: string;
  status: MatchStatus;
  time?: string;
  details?: string;
  scorers?: string[];
  // Cricket-specific
  batting?: string;
  crr?: string;
  rrr?: string;
  target?: number;
}

export interface NewsArticle {
  id: string;
  title: string;
  excerpt: string;
  sport: Sport;
  timeAgo: string;
  imageUrl: string;
  breaking?: boolean;
}

export interface StandingsRow {
  pos: number;
  team: string;
  code: string;
  played: number;
  won: number;
  drawn: number;
  lost: number;
  gd: number;
  pts: number;
}

export interface TopScorer {
  name: string;
  team: string;
  goals: number;
  assists: number;
  imageInitials: string;
}

export const mockMatches: Match[] = [
  {
    id: "f1",
    sport: "Football",
    competition: "La Liga",
    team1: "Real Madrid",
    team1Code: "RMA",
    team2: "Barcelona",
    team2Code: "BAR",
    score1: "2",
    score2: "1",
    status: "LIVE",
    time: "67'",
    scorers: ["Vinicius Jr 23'", "Mbappe 67'", "Lewandowski 45+1'"],
  },
  {
    id: "f2",
    sport: "Football",
    competition: "Premier League",
    team1: "Manchester City",
    team1Code: "MCI",
    team2: "Arsenal",
    team2Code: "ARS",
    score1: "0",
    score2: "0",
    status: "LIVE",
    time: "34'",
    scorers: [],
  },
  {
    id: "f3",
    sport: "Football",
    competition: "Premier League",
    team1: "Liverpool",
    team1Code: "LIV",
    team2: "Chelsea",
    team2Code: "CHE",
    score1: "1",
    score2: "1",
    status: "HT",
    scorers: ["Salah 18'", "Palmer 41'"],
  },
  {
    id: "f4",
    sport: "Football",
    competition: "UEFA Champions League",
    team1: "Bayern Munich",
    team1Code: "BAY",
    team2: "PSG",
    team2Code: "PSG",
    status: "Upcoming",
    time: "20:45",
  },
  {
    id: "f5",
    sport: "Football",
    competition: "Serie A",
    team1: "Juventus",
    team1Code: "JUV",
    team2: "Inter Milan",
    team2Code: "INT",
    score1: "2",
    score2: "3",
    status: "FT",
    scorers: ["Vlahovic 12'", "Yildiz 55'", "Martinez 8'", "Thuram 71'", "Barella 90+3'"],
  },
  {
    id: "c1",
    sport: "Cricket",
    competition: "ICC Champions Trophy",
    team1: "India",
    team1Code: "IND",
    team2: "Australia",
    team2Code: "AUS",
    score1: "287/6",
    score2: "311",
    status: "LIVE",
    time: "42.3 ov",
    details: "IND need 25 runs off 45 balls",
    batting: "Kohli 87* (92) • Jadeja 34* (28)",
    crr: "6.75",
    rrr: "3.33",
    target: 312,
  },
  {
    id: "c2",
    sport: "Cricket",
    competition: "Test Series",
    team1: "England",
    team1Code: "ENG",
    team2: "South Africa",
    team2Code: "SA",
    score1: "145/3",
    score2: "288",
    status: "LIVE",
    time: "28 ov",
    details: "ENG need 144 runs off 132 balls",
    batting: "Root 67* (78) • Stokes 12* (14)",
    crr: "5.18",
    rrr: "6.55",
    target: 289,
  },
  {
    id: "c3",
    sport: "Cricket",
    competition: "T20 Series",
    team1: "Pakistan",
    team1Code: "PAK",
    team2: "New Zealand",
    team2Code: "NZ",
    status: "Upcoming",
    time: "Tomorrow 10:00 AM",
  },
  {
    id: "c4",
    sport: "Cricket",
    competition: "ODI Series",
    team1: "West Indies",
    team1Code: "WI",
    team2: "Sri Lanka",
    team2Code: "SL",
    score1: "198/6",
    score2: "196",
    status: "FT",
    details: "WI won by 4 wickets",
  },
];

export const mockNews: NewsArticle[] = [
  {
    id: "n1",
    title: "Mbappe fires Real Madrid to El Clasico lead",
    excerpt: "Kylian Mbappe's stunning curler in the 67th minute gave Real Madrid a commanding lead at the Bernabeu.",
    sport: "Football",
    timeAgo: "12 min ago",
    imageUrl: "https://images.unsplash.com/photo-1579952363873-27f3bade9f55?q=80&w=600&auto=format&fit=crop",
    breaking: true,
  },
  {
    id: "n2",
    title: "Kohli's unbeaten 87 steers India to commanding position",
    excerpt: "Virat Kohli's masterclass innings has India on course for a famous victory against Australia.",
    sport: "Cricket",
    timeAgo: "25 min ago",
    imageUrl: "https://images.unsplash.com/photo-1531415074968-036ba1b575da?q=80&w=600&auto=format&fit=crop",
    breaking: true,
  },
  {
    id: "n3",
    title: "Haaland injury scare ahead of Champions League",
    excerpt: "Manchester City striker Erling Haaland limped off in training raising concerns for Tuesday's clash.",
    sport: "Football",
    timeAgo: "1 hr ago",
    imageUrl: "https://images.unsplash.com/photo-1518605368461-1ee12523f208?q=80&w=600&auto=format&fit=crop",
  },
  {
    id: "n4",
    title: "Ben Stokes announces Test retirement timeline",
    excerpt: "England's Test captain Ben Stokes has hinted at his future plans after the upcoming Ashes series.",
    sport: "Cricket",
    timeAgo: "2 hrs ago",
    imageUrl: "https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?q=80&w=600&auto=format&fit=crop",
  },
  {
    id: "n5",
    title: "Premier League title race: City and Arsenal level on points",
    excerpt: "With five games to play, the Premier League title race has never been tighter. Here's our analysis.",
    sport: "Football",
    timeAgo: "3 hrs ago",
    imageUrl: "https://images.unsplash.com/photo-1522778119026-d647f0596c20?q=80&w=600&auto=format&fit=crop",
  },
  {
    id: "n6",
    title: "IPL 2026 mega auction date officially confirmed",
    excerpt: "The Board of Control for Cricket in India has confirmed the IPL 2026 mega auction will take place in December.",
    sport: "Cricket",
    timeAgo: "5 hrs ago",
    imageUrl: "https://images.unsplash.com/photo-1587280501635-68a0e82cd5ff?q=80&w=600&auto=format&fit=crop",
  },
  {
    id: "n7",
    title: "Champions League quarter-final draw: who plays who?",
    excerpt: "Real Madrid face a tough test while Man City got what many consider the easier path to the semis.",
    sport: "Football",
    timeAgo: "8 hrs ago",
    imageUrl: "https://images.unsplash.com/photo-1489944440615-453fc2b6a9a9?q=80&w=600&auto=format&fit=crop",
  },
  {
    id: "n8",
    title: "ICC World Cup 2027 full schedule and venues released",
    excerpt: "The ICC has released the complete schedule for the 2027 Cricket World Cup to be hosted across three nations.",
    sport: "Cricket",
    timeAgo: "1 day ago",
    imageUrl: "https://images.unsplash.com/photo-1624194638662-7e1329243765?q=80&w=600&auto=format&fit=crop",
  },
];

export const laLigaStandings: StandingsRow[] = [
  { pos: 1, team: "Real Madrid", code: "RMA", played: 33, won: 24, drawn: 5, lost: 4, gd: 42, pts: 77 },
  { pos: 2, team: "Barcelona", code: "BAR", played: 33, won: 23, drawn: 4, lost: 6, gd: 38, pts: 73 },
  { pos: 3, team: "Atletico Madrid", code: "ATM", played: 33, won: 19, drawn: 7, lost: 7, gd: 21, pts: 64 },
  { pos: 4, team: "Athletic Bilbao", code: "ATH", played: 33, won: 18, drawn: 6, lost: 9, gd: 14, pts: 60 },
  { pos: 5, team: "Villarreal", code: "VIL", played: 33, won: 16, drawn: 8, lost: 9, gd: 11, pts: 56 },
];

export const premierLeagueStandings: StandingsRow[] = [
  { pos: 1, team: "Manchester City", code: "MCI", played: 33, won: 22, drawn: 7, lost: 4, gd: 39, pts: 73 },
  { pos: 2, team: "Arsenal", code: "ARS", played: 33, won: 22, drawn: 7, lost: 4, gd: 36, pts: 73 },
  { pos: 3, team: "Liverpool", code: "LIV", played: 33, won: 20, drawn: 8, lost: 5, gd: 33, pts: 68 },
  { pos: 4, team: "Chelsea", code: "CHE", played: 33, won: 17, drawn: 6, lost: 10, gd: 15, pts: 57 },
  { pos: 5, team: "Tottenham", code: "TOT", played: 33, won: 15, drawn: 5, lost: 13, gd: 8, pts: 50 },
];

export const topScorers: TopScorer[] = [
  { name: "Kylian Mbappe", team: "Real Madrid", goals: 28, assists: 12, imageInitials: "KM" },
  { name: "Erling Haaland", team: "Man City", goals: 24, assists: 6, imageInitials: "EH" },
  { name: "Robert Lewandowski", team: "Barcelona", goals: 22, assists: 8, imageInitials: "RL" },
  { name: "Mohamed Salah", team: "Liverpool", goals: 20, assists: 14, imageInitials: "MS" },
  { name: "Cole Palmer", team: "Chelsea", goals: 18, assists: 11, imageInitials: "CP" },
];
