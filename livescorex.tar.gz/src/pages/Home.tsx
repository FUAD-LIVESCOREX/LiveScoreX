import { Link } from "wouter";
import { Header } from "@/components/Header";
import { BottomNav } from "@/components/BottomNav";
import { MatchCard } from "@/components/MatchCard";
import { AdBanner } from "@/components/AdBanner";
import { mockMatches, mockNews } from "@/data/mockData";
import { ChevronRight, TrendingUp, Zap } from "lucide-react";

export default function Home() {
  const liveMatches = mockMatches.filter(m => m.status === "LIVE");
  const featuredMatch = mockMatches.find(m => m.id === "f1")!;
  const topNews = mockNews.slice(0, 4);

  return (
    <div className="min-h-[100dvh] pb-20 md:pb-8 flex flex-col">
      <Header />

      <main className="flex-1 max-w-5xl mx-auto w-full px-4 sm:px-6 md:px-8 py-5 flex flex-col gap-7">

        {/* Sport filter tabs */}
        <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-none -mx-1 px-1" data-testid="quick-tabs">
          <button className="whitespace-nowrap px-4 py-1.5 rounded-full bg-primary text-primary-foreground font-bold text-xs tracking-wide">All Sports</button>
          <Link href="/football" className="whitespace-nowrap px-4 py-1.5 rounded-full bg-secondary text-secondary-foreground font-bold text-xs tracking-wide hover:bg-accent transition-colors">Football</Link>
          <Link href="/cricket" className="whitespace-nowrap px-4 py-1.5 rounded-full bg-secondary text-secondary-foreground font-bold text-xs tracking-wide hover:bg-accent transition-colors">Cricket</Link>
          <Link href="/live" className="whitespace-nowrap px-4 py-1.5 rounded-full bg-live/10 text-live font-bold text-xs tracking-wide border border-live/20 flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-live animate-pulse" /> Live Now
          </Link>
        </div>

        {/* Featured match */}
        <section>
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Zap className="w-4 h-4 text-primary" />
              <h2 className="text-base font-black tracking-tight uppercase text-muted-foreground">Trending Match</h2>
            </div>
          </div>
          <MatchCard match={featuredMatch} featured />
        </section>

        {/* Live matches strip */}
        <section>
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-live animate-pulse" />
              <h2 className="text-lg font-black tracking-tight">Live Now</h2>
              <span className="text-xs font-bold text-live bg-live/10 px-1.5 py-0.5 rounded-full">{liveMatches.length}</span>
            </div>
            <Link href="/live" className="text-xs font-bold text-primary flex items-center gap-0.5 hover:underline" data-testid="see-all-live">
              See All <ChevronRight className="w-3.5 h-3.5" />
            </Link>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {liveMatches.map(match => (
              <MatchCard key={match.id} match={match} />
            ))}
          </div>
        </section>

        <AdBanner />

        {/* Top News */}
        <section>
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-primary" />
              <h2 className="text-lg font-black tracking-tight">Top Stories</h2>
            </div>
            <Link href="/news" className="text-xs font-bold text-primary flex items-center gap-0.5 hover:underline" data-testid="see-all-news">
              More <ChevronRight className="w-3.5 h-3.5" />
            </Link>
          </div>

          {/* Hero news item */}
          <Link href="/news" className="block group cursor-pointer mb-3" data-testid="news-hero">
            <div className="relative aspect-[16/7] rounded-xl overflow-hidden mb-3 bg-muted">
              <img src={topNews[0].imageUrl} alt={topNews[0].title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 p-4">
                <div className="flex items-center gap-2 mb-1.5">
                  {topNews[0].breaking && (
                    <span className="text-[9px] font-black uppercase tracking-widest bg-red-600 text-white px-1.5 py-0.5 rounded-sm">Breaking</span>
                  )}
                  <span className="text-[10px] font-bold text-white/70 uppercase tracking-wider">{topNews[0].sport} · {topNews[0].timeAgo}</span>
                </div>
                <h3 className="font-black text-white text-base leading-snug">{topNews[0].title}</h3>
              </div>
            </div>
          </Link>

          {/* 3 smaller news items */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {topNews.slice(1, 4).map(article => (
              <div key={article.id} className="flex gap-3 sm:flex-col sm:gap-2 group cursor-pointer" data-testid={`news-card-${article.id}`}>
                <div className="w-20 h-16 sm:w-full sm:h-24 rounded-lg overflow-hidden bg-muted shrink-0">
                  <img src={article.imageUrl} alt={article.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                </div>
                <div className="flex flex-col justify-center gap-1 min-w-0">
                  <div className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wider">
                    <span className="text-primary">{article.sport}</span>
                    <span className="text-muted-foreground/50">·</span>
                    <span className="text-muted-foreground">{article.timeAgo}</span>
                  </div>
                  <h3 className="font-bold text-sm leading-snug text-foreground group-hover:text-primary transition-colors line-clamp-2">{article.title}</h3>
                </div>
              </div>
            ))}
          </div>
        </section>

      </main>

      <BottomNav />
    </div>
  );
}
