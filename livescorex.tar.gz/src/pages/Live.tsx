import { useState, useEffect, useCallback } from "react";
import { Header } from "@/components/Header";
import { BottomNav } from "@/components/BottomNav";
import { MatchCard } from "@/components/MatchCard";
import { mockMatches, Match } from "@/data/mockData";
import { RefreshCw } from "lucide-react";

const REFRESH_INTERVAL = 30;

function nudgeScores(matches: Match[]): Match[] {
  return matches.map(m => {
    if (m.sport === "Football" && Math.random() > 0.8) {
      const s1 = parseInt(m.score1 ?? "0") + 1;
      const newScorers = [...(m.scorers ?? []), `Goal ${s1}`];
      return { ...m, score1: s1.toString(), scorers: newScorers };
    }
    return m;
  });
}

export default function Live() {
  const [countdown, setCountdown] = useState(REFRESH_INTERVAL);
  const [matches, setMatches] = useState<Match[]>(mockMatches.filter(m => m.status === "LIVE"));
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [lastUpdated, setLastUpdated] = useState(new Date());

  const refresh = useCallback(() => {
    setIsRefreshing(true);
    setTimeout(() => {
      setMatches(prev => nudgeScores(prev));
      setLastUpdated(new Date());
      setIsRefreshing(false);
    }, 600);
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      setCountdown(prev => {
        if (prev <= 1) { refresh(); return REFRESH_INTERVAL; }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [refresh]);

  const footballMatches = matches.filter(m => m.sport === "Football");
  const cricketMatches = matches.filter(m => m.sport === "Cricket");

  const progressPct = ((REFRESH_INTERVAL - countdown) / REFRESH_INTERVAL) * 100;

  return (
    <div className="min-h-[100dvh] pb-20 md:pb-8 flex flex-col">
      <Header />
      <main className="flex-1 max-w-5xl mx-auto w-full px-4 sm:px-6 md:px-8 py-5 flex flex-col gap-6">

        {/* Header */}
        <div className="flex items-center justify-between gap-4 flex-wrap">
          <div className="flex items-center gap-3">
            <div className="relative w-10 h-10 shrink-0">
              <div className="absolute inset-0 rounded-full bg-live/20 animate-ping opacity-40" />
              <div className="relative w-10 h-10 rounded-full bg-live/20 flex items-center justify-center">
                <span className="w-3.5 h-3.5 rounded-full bg-live" />
              </div>
            </div>
            <div>
              <h1 className="text-2xl font-black tracking-tight">Live Center</h1>
              <p className="text-xs text-muted-foreground font-medium">
                {matches.length} matches · Updated {lastUpdated.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
              </p>
            </div>
          </div>

          <button
            onClick={() => { refresh(); setCountdown(REFRESH_INTERVAL); }}
            data-testid="refresh-button"
            className="flex items-center gap-2 bg-card border border-border rounded-full px-4 py-2 text-sm font-semibold hover:border-primary/40 transition-colors"
          >
            <RefreshCw className={`w-3.5 h-3.5 text-muted-foreground ${isRefreshing ? "animate-spin" : ""}`} />
            <span className="text-muted-foreground">
              Refresh in <span className="text-foreground font-black tabular-nums">{countdown}s</span>
            </span>
          </button>
        </div>

        {/* Progress bar */}
        <div className="h-0.5 bg-border rounded-full overflow-hidden -mt-3">
          <div
            className="h-full bg-live transition-all duration-1000 ease-linear rounded-full"
            style={{ width: `${progressPct}%` }}
          />
        </div>

        {/* Football section */}
        {footballMatches.length > 0 && (
          <section>
            <div className="flex items-center gap-2 mb-3">
              <h2 className="text-sm font-black uppercase tracking-wider text-muted-foreground">Football</h2>
              <div className="flex-1 h-px bg-border" />
              <span className="text-xs font-bold text-live">{footballMatches.length} live</span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {footballMatches.map(match => <MatchCard key={match.id} match={match} />)}
            </div>
          </section>
        )}

        {/* Cricket section */}
        {cricketMatches.length > 0 && (
          <section>
            <div className="flex items-center gap-2 mb-3">
              <h2 className="text-sm font-black uppercase tracking-wider text-muted-foreground">Cricket</h2>
              <div className="flex-1 h-px bg-border" />
              <span className="text-xs font-bold text-live">{cricketMatches.length} live</span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {cricketMatches.map(match => <MatchCard key={match.id} match={match} />)}
            </div>
          </section>
        )}

      </main>
      <BottomNav />
    </div>
  );
}
