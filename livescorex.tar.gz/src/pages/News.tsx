import { useState } from "react";
import { Header } from "@/components/Header";
import { BottomNav } from "@/components/BottomNav";
import { mockNews, Sport } from "@/data/mockData";

type Filter = "all" | Sport;

export default function News() {
  const [filter, setFilter] = useState<Filter>("all");

  const filtered = filter === "all" ? mockNews : mockNews.filter(a => a.sport === filter);
  const [hero, ...rest] = filtered;

  return (
    <div className="min-h-[100dvh] pb-20 md:pb-8 flex flex-col">
      <Header />
      <main className="flex-1 max-w-5xl mx-auto w-full px-4 sm:px-6 md:px-8 py-5 flex flex-col gap-6">

        <div>
          <h1 className="text-3xl font-black tracking-tight">Latest News</h1>
          <p className="text-muted-foreground text-sm font-medium mt-0.5">Breaking stories, analysis & updates</p>
        </div>

        {/* Filter tabs */}
        <div className="flex gap-2" data-testid="news-filters">
          {(["all", "Football", "Cricket"] as Filter[]).map(f => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              data-testid={`news-filter-${f}`}
              className={`px-4 py-1.5 rounded-full text-xs font-bold transition-colors ${filter === f ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground hover:text-foreground"}`}
            >
              {f === "all" ? "All" : f}
            </button>
          ))}
        </div>

        {hero && (
          <div className="group cursor-pointer" data-testid="news-hero">
            <div className="relative aspect-[16/7] rounded-2xl overflow-hidden mb-4 bg-muted">
              <img src={hero.imageUrl} alt={hero.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/30 to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 p-5">
                <div className="flex items-center gap-2 mb-2">
                  {hero.breaking && (
                    <span className="text-[9px] font-black uppercase tracking-widest bg-red-600 text-white px-2 py-0.5 rounded-sm">Breaking</span>
                  )}
                  <span className="text-[10px] font-bold text-white/60 uppercase tracking-wider">{hero.sport} · {hero.timeAgo}</span>
                </div>
                <h2 className="font-black text-white text-xl leading-snug">{hero.title}</h2>
                <p className="text-white/70 text-sm mt-1.5 leading-relaxed line-clamp-2">{hero.excerpt}</p>
              </div>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {rest.map(article => (
            <div key={article.id} className="flex gap-4 group cursor-pointer" data-testid={`news-card-${article.id}`}>
              <div className="w-24 h-20 rounded-xl overflow-hidden bg-muted shrink-0">
                <img src={article.imageUrl} alt={article.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
              </div>
              <div className="flex flex-col justify-center gap-1.5 min-w-0 flex-1 py-1">
                <div className="flex items-center gap-2">
                  <span className={`text-[9px] font-black uppercase tracking-wider px-1.5 py-0.5 rounded-sm ${article.sport === "Football" ? "bg-primary/10 text-primary" : "bg-amber-400/10 text-amber-400"}`}>
                    {article.sport}
                  </span>
                  <span className="text-[10px] text-muted-foreground font-medium">{article.timeAgo}</span>
                </div>
                <h3 className="font-bold text-sm leading-snug group-hover:text-primary transition-colors line-clamp-2">{article.title}</h3>
                <p className="text-xs text-muted-foreground leading-relaxed line-clamp-2 hidden sm:block">{article.excerpt}</p>
              </div>
            </div>
          ))}
        </div>

      </main>
      <BottomNav />
    </div>
  );
}
