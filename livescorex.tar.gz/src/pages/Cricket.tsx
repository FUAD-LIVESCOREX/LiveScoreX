import { useState } from "react";
import { Header } from "@/components/Header";
import { BottomNav } from "@/components/BottomNav";
import { MatchCard } from "@/components/MatchCard";
import { AdBanner } from "@/components/AdBanner";
import { mockMatches } from "@/data/mockData";

type Filter = "all" | "odi" | "test" | "t20";

const seriesInfo = [
  { name: "ICC Champions Trophy", teams: "10 Teams", matches: "15 Matches", status: "Ongoing", statusColor: "text-live" },
  { name: "England vs South Africa", teams: "Test Series", matches: "3 Tests", status: "2nd Test", statusColor: "text-amber-400" },
  { name: "Pakistan vs New Zealand", teams: "T20 Series", matches: "5 T20Is", status: "Upcoming", statusColor: "text-muted-foreground" },
  { name: "West Indies vs Sri Lanka", teams: "ODI Series", matches: "3 ODIs", status: "WI won 2-1", statusColor: "text-primary" },
];

export default function Cricket() {
  const [filter, setFilter] = useState<Filter>("all");
  const matches = mockMatches.filter(m => m.sport === "Cricket");
  const liveMatches = matches.filter(m => m.status === "LIVE");
  const otherMatches = matches.filter(m => m.status !== "LIVE");

  return (
    <div className="min-h-[100dvh] pb-20 md:pb-8 flex flex-col">
      <Header />
      <main className="flex-1 max-w-5xl mx-auto w-full px-4 sm:px-6 md:px-8 py-5 flex flex-col gap-6">

        <div className="flex items-end justify-between">
          <div>
            <h1 className="text-3xl font-black tracking-tight">Cricket</h1>
            <p className="text-muted-foreground text-sm font-medium mt-0.5">Live scores, series & stats</p>
          </div>
          <div className="flex items-center gap-1.5 text-xs font-bold text-live bg-live/10 px-3 py-1.5 rounded-full border border-live/20">
            <span className="w-1.5 h-1.5 rounded-full bg-live animate-pulse" />
            {liveMatches.length} LIVE
          </div>
        </div>

        {/* Format filter */}
        <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-none">
          {(["all", "odi", "test", "t20"] as Filter[]).map(f => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              data-testid={`filter-${f}`}
              className={`whitespace-nowrap px-4 py-1.5 rounded-full text-xs font-bold transition-colors ${filter === f ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground hover:text-foreground"}`}
            >
              {f === "all" ? "All Formats" : f === "odi" ? "ODI" : f === "test" ? "Test" : "T20"}
            </button>
          ))}
        </div>

        {/* Live matches */}
        {liveMatches.length > 0 && (
          <section>
            <div className="flex items-center gap-2 mb-3">
              <span className="w-2 h-2 rounded-full bg-live animate-pulse" />
              <h2 className="text-base font-black">Live Matches</h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {liveMatches.map(match => <MatchCard key={match.id} match={match} />)}
            </div>
          </section>
        )}

        <AdBanner />

        {/* Series overview */}
        <section>
          <h2 className="text-base font-black mb-3">Active Series</h2>
          <div className="bg-card border border-card-border rounded-xl overflow-hidden divide-y divide-card-border/50">
            {seriesInfo.map((series, i) => (
              <div key={i} className="flex items-center justify-between px-4 py-3.5 hover:bg-accent/30 transition-colors cursor-pointer" data-testid={`series-${i}`}>
                <div>
                  <div className="font-bold text-sm">{series.name}</div>
                  <div className="text-xs text-muted-foreground font-medium mt-0.5">{series.teams} · {series.matches}</div>
                </div>
                <span className={`text-xs font-bold ${series.statusColor}`}>{series.status}</span>
              </div>
            ))}
          </div>
        </section>

        {/* Results & Upcoming */}
        <section>
          <h2 className="text-base font-black mb-3">Results & Upcoming</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {otherMatches.map(match => <MatchCard key={match.id} match={match} />)}
          </div>
        </section>

      </main>
      <BottomNav />
    </div>
  );
}
