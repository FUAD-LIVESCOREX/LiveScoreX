import { useState } from "react";
import { Header } from "@/components/Header";
import { BottomNav } from "@/components/BottomNav";
import { MatchCard } from "@/components/MatchCard";
import { AdBanner } from "@/components/AdBanner";
import { mockMatches, laLigaStandings, premierLeagueStandings, topScorers } from "@/data/mockData";
import { Trophy, TrendingUp, BarChart2 } from "lucide-react";

type Tab = "scores" | "standings" | "scorers";

export default function Football() {
  const [tab, setTab] = useState<Tab>("scores");
  const matches = mockMatches.filter(m => m.sport === "Football");
  const liveMatches = matches.filter(m => m.status === "LIVE" || m.status === "HT");
  const otherMatches = matches.filter(m => m.status === "Upcoming" || m.status === "FT");

  return (
    <div className="min-h-[100dvh] pb-20 md:pb-8 flex flex-col">
      <Header />
      <main className="flex-1 max-w-5xl mx-auto w-full px-4 sm:px-6 md:px-8 py-5 flex flex-col gap-6">

        <div className="flex items-end justify-between">
          <div>
            <h1 className="text-3xl font-black tracking-tight">Football</h1>
            <p className="text-muted-foreground text-sm font-medium mt-0.5">Live scores, standings & stats</p>
          </div>
          <div className="flex items-center gap-1.5 text-xs font-bold text-live bg-live/10 px-3 py-1.5 rounded-full border border-live/20">
            <span className="w-1.5 h-1.5 rounded-full bg-live animate-pulse" />
            {liveMatches.length} LIVE
          </div>
        </div>

        {/* Tab bar */}
        <div className="flex gap-1 bg-secondary rounded-xl p-1">
          {([
            { id: "scores", label: "Scores", Icon: Trophy },
            { id: "standings", label: "Standings", Icon: BarChart2 },
            { id: "scorers", label: "Top Scorers", Icon: TrendingUp },
          ] as { id: Tab; label: string; Icon: React.ElementType }[]).map(({ id, label, Icon }) => (
            <button
              key={id}
              onClick={() => setTab(id)}
              data-testid={`tab-${id}`}
              className={`flex-1 flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg text-xs font-bold transition-all ${tab === id ? "bg-card text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"}`}
            >
              <Icon className="w-3.5 h-3.5" />
              {label}
            </button>
          ))}
        </div>

        {tab === "scores" && (
          <>
            {liveMatches.length > 0 && (
              <section>
                <div className="flex items-center gap-2 mb-3">
                  <span className="w-2 h-2 rounded-full bg-live animate-pulse" />
                  <h2 className="text-base font-black">Live & In Progress</h2>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {liveMatches.map(match => <MatchCard key={match.id} match={match} />)}
                </div>
              </section>
            )}

            <AdBanner />

            <section>
              <h2 className="text-base font-black mb-3">Upcoming & Results</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {otherMatches.map(match => <MatchCard key={match.id} match={match} />)}
              </div>
            </section>
          </>
        )}

        {tab === "standings" && (
          <div className="flex flex-col gap-6">
            {[
              { title: "La Liga", data: laLigaStandings },
              { title: "Premier League", data: premierLeagueStandings },
            ].map(({ title, data }) => (
              <section key={title}>
                <h2 className="text-base font-black mb-3 flex items-center gap-2">
                  <Trophy className="w-4 h-4 text-primary" /> {title}
                </h2>
                <div className="bg-card border border-card-border rounded-xl overflow-hidden">
                  <div className="grid grid-cols-[24px_1fr_32px_32px_32px_32px_36px] gap-x-2 px-4 py-2.5 text-[10px] font-bold uppercase tracking-wider text-muted-foreground border-b border-card-border">
                    <span>#</span><span>Team</span><span className="text-center">P</span><span className="text-center">W</span><span className="text-center">D</span><span className="text-center">L</span><span className="text-right font-black">Pts</span>
                  </div>
                  {data.map((row, i) => (
                    <div key={row.pos} className={`grid grid-cols-[24px_1fr_32px_32px_32px_32px_36px] gap-x-2 px-4 py-3 text-sm items-center ${i < data.length - 1 ? "border-b border-card-border/50" : ""} ${i < 4 ? "border-l-2 border-l-primary" : ""}`}>
                      <span className="text-xs font-bold text-muted-foreground">{row.pos}</span>
                      <span className="font-semibold truncate">{row.team}</span>
                      <span className="text-center text-muted-foreground text-xs">{row.played}</span>
                      <span className="text-center text-muted-foreground text-xs">{row.won}</span>
                      <span className="text-center text-muted-foreground text-xs">{row.drawn}</span>
                      <span className="text-center text-muted-foreground text-xs">{row.lost}</span>
                      <span className="text-right font-black text-primary">{row.pts}</span>
                    </div>
                  ))}
                </div>
                <p className="text-[10px] text-muted-foreground mt-1.5 px-1">Blue bar = Champions League qualification</p>
              </section>
            ))}
          </div>
        )}

        {tab === "scorers" && (
          <section>
            <h2 className="text-base font-black mb-3">Top Scorers — All Leagues</h2>
            <div className="bg-card border border-card-border rounded-xl overflow-hidden">
              {topScorers.map((player, i) => (
                <div key={player.name} className={`flex items-center gap-4 px-4 py-3.5 ${i < topScorers.length - 1 ? "border-b border-card-border/50" : ""}`} data-testid={`scorer-${i}`}>
                  <span className="text-lg font-black text-muted-foreground/40 w-6 text-center">{i + 1}</span>
                  <div className="w-9 h-9 rounded-full bg-primary/20 flex items-center justify-center text-primary font-black text-xs shrink-0">
                    {player.imageInitials}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-bold text-sm">{player.name}</div>
                    <div className="text-xs text-muted-foreground font-medium">{player.team}</div>
                  </div>
                  <div className="flex items-center gap-4 text-sm shrink-0">
                    <div className="text-center">
                      <div className="font-black text-foreground">{player.goals}</div>
                      <div className="text-[9px] text-muted-foreground uppercase tracking-wider">Goals</div>
                    </div>
                    <div className="text-center">
                      <div className="font-black text-muted-foreground">{player.assists}</div>
                      <div className="text-[9px] text-muted-foreground uppercase tracking-wider">Assists</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </section>
        )}

      </main>
      <BottomNav />
    </div>
  );
}
